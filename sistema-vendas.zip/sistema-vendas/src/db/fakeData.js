let categoriasDeProduto = [
    {
        id:1,
        descricao:"Celulares"
    },
    {
        id:2,
        descricao:"Computadores"
    },
    {
        id:3,
        descricao:"Consoles de Videogame"
    }
]
let clientes = [
    {
        id:1,
        nome:"Hirai Momo",
        cpf:"06122542555"
    },
    {
        id:2,
        nome:"Minatozaki Sana",
        cpf:"06122542522"
    },
    {
        id:3,
        nome:"Im Nayeon",
        cpf:"06122542525"
    }
]
module.exports = {categoriasDeProduto,clientes}